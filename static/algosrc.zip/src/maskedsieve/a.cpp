#include<cstdio>
int main() {
	int k;
	scanf("%d", &k);
	printf("%d\n", k / 8);
}
