#!/usr/bin/python
from random import sample
print 50
print "\n".join(map(str, sample(range(1,101),50)))
